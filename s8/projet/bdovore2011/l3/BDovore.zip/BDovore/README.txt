Pour un meilleur confort d'utilisation (et �viter une premi�re mise � jour trop longue), t�l�chargez la derni�re version de la base de donn�es � l'adresse suivante :

http://bdovore.googlecode.com/  (fichier "db-<date>.zip")

Son contenu est � placer dans le dossier "db" du logiciel
